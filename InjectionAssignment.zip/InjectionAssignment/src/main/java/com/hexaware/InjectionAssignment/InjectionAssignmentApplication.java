package com.hexaware.InjectionAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InjectionAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(InjectionAssignmentApplication.class, args);
	}

}
