package consDIdemo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("mySqlDataSource")
@Primary
public class MySqlDataSource implements DataSource{

	@Override
	public void returnConnection() {
		// TODO Auto-generated method stub
		System.out.println("connection is returned from MySql.");
	}

}
