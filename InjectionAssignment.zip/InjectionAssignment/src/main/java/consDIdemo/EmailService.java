package consDIdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("emailService")
public class EmailService {
	
	private DataSource dataSource1;
	private DataSource dataSource2;
	
//	public EmailService(@Qualifier("mySqlDataSource") DataSource dataSource1,@Qualifier("postgreSqlDataSource") DataSource dataSource2) {
//		super();
//		this.dataSource1 = dataSource1;
//		this.dataSource2 = dataSource2;
//	}
	@Autowired
	public void setDataSource1(DataSource dataSource1) {
		this.dataSource1 = dataSource1;
	}

	@Autowired
	public void setDataSource2(@Qualifier("postgreSqlDataSource") DataSource dataSource2) {
		this.dataSource2 = dataSource2;
	}
	
	public void sendEmail(String type) {
		if(type.contentEquals("mysql")) {
			this.dataSource1.returnConnection();
		} else {
			this.dataSource2.returnConnection();
		}
	}
}
