package consDIdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String mySql = "mysql";
		String postgreSql = "postgresql";
		
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		EmailService service = context.getBean(EmailService.class);
		
		service.sendEmail(mySql);
		service.sendEmail(postgreSql);
	}

}
