package consDIdemo;

public interface DataSource {
	public void returnConnection();

}
