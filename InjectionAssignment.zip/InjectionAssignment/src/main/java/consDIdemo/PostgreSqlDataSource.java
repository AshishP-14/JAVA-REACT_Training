package consDIdemo;

import org.springframework.stereotype.Component;

@Component("postgreSqlDataSource") 
public class PostgreSqlDataSource implements DataSource {

	@Override
	public void returnConnection() {
		// TODO Auto-generated method stub
		System.out.println("connection is returned from PostgreSql.");
	}

}
