/*
 * 4.URL Parser and Builder: Create a class called URLParser that parses a URL into itsrs components (protocol, host, path, query paramete, etc.).implement a class named URLBuilder that constructs a URL from its components.
 */


import java.util.HashMap;
import java.util.Map;

public class URLParser {

    private String url;
    private String protocol;
    private String host;
    private String path;
    private Map<String, String> queryParams;

    public URLParser(String url) {
        this.url = url;
        parseURL();
    }

    private void parseURL() {
        // Split the URL into parts using regex
        String[] parts = url.split("://");

        if (parts.length > 1) {
            protocol = parts[0];
            String remaining = parts[1];
            String[] remainingParts = remaining.split("/",2);
            host = remainingParts[0];
            if(remainingParts.length >1) {
            	String pathAndQuery = remainingParts[1];
            	String[] pathAndQueryParts = pathAndQuery.split("\\?",2);
            	path = pathAndQueryParts[0];
            	
            	if(pathAndQueryParts.length >1) {
            		queryParams = parseQueryParams(pathAndQueryParts[1]);
            	}
            }
        }
    }

    private Map<String, String> parseQueryParams(String string) {
		Map<String, String> params = new HashMap<>();
		String[] pairs = string.split("&");
		for(String pair : pairs) {
			String[] keyValue = pair.split("=");
			if(keyValue.length == 2) {
				params.put(keyValue[0], keyValue[1]);
			}
		}
		return params;
	}

	public String getProtocol() {
        return protocol;
    }

    public String getHost() {
        return host;
    }

    public String getPath() {
        return path;
    }

    public Map<String, String> getQueryParams() {
        return queryParams;
    }

    public static void main(String[] args) {
        URLParser urlParser = new URLParser("https://github.com/AshishP-14/JAVA-REACT_Training/blob/main/BankingApplication.rar?param1=value1&param2=value2");

        System.out.println("Protocol: " + urlParser.getProtocol());
        System.out.println("Host: " + urlParser.getHost());
        System.out.println("Path: " + urlParser.getPath());
        System.out.println("Query Parameters: " + urlParser.getQueryParams());
    }
}
