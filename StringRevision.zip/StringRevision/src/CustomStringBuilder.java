import java.util.Arrays;

/*
 * Build a simplified version of the StringBuilder class. 
 * Your custom class should support basic string manipulation operations such as:
 * Appending a string.Inserting a string at a specific index.
 * Deleting a portion of the string.
 * 
 */



public class CustomStringBuilder {

    private char[] value;
    private int size;

    public CustomStringBuilder() {
        this.value = new char[16];  // Initial capacity
        this.size = 0;
    }

    public void append(String str) {
        ensureCapacity(size + str.length());
        str.getChars(0, str.length(), value, size);
        size += str.length();
    }

    public void insert(int index, String str) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }

        ensureCapacity(size + str.length());
        System.arraycopy(value, index, value, index + str.length(), size - index);
        str.getChars(0, str.length(), value, index);
        size += str.length();
    }

    public void delete(int startIndex, int endIndex) {
        if (startIndex < 0 || startIndex >= size || endIndex > size || startIndex > endIndex) {
            throw new IndexOutOfBoundsException("Invalid start or end index");
        }

        int numOfCharsToRemove = endIndex - startIndex;
        System.arraycopy(value, endIndex, value, startIndex, size - endIndex);
        size -= numOfCharsToRemove;
    }

    @Override
    public String toString() {
        return new String(value, 0, size);
    }

    private void ensureCapacity(int minCapacity) {
        if (minCapacity > value.length) {
            int newCapacity = Math.max(value.length * 2, minCapacity);
            value = Arrays.copyOf(value, newCapacity);
        }
    }

    public static void main(String[] args) {
        CustomStringBuilder customStringBuilder = new CustomStringBuilder();

        customStringBuilder.append("Hello, ");
        customStringBuilder.append("world!");

        System.out.println("After appending: " + customStringBuilder);

        customStringBuilder.insert(7, "beautiful ");
        System.out.println("After inserting: " + customStringBuilder);

        customStringBuilder.delete(7, 17);
        System.out.println("After deleting: " + customStringBuilder);
    }
}
