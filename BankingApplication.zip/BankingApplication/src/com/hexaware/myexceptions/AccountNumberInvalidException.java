package com.hexaware.myexceptions;

public class AccountNumberInvalidException extends Exception{

	private String message;

	public AccountNumberInvalidException(String message) {
		super(message);
		
	}

	public AccountNumberInvalidException() {
		super();
		this.message = "Account number invalid";
	}
	
}
