package com.hexaware.myexceptions;

public class InsufficientFundException extends Exception{
	
	public InsufficientFundException(String message) {
		super(message + "insufficient fund in account");
		
	}

}
