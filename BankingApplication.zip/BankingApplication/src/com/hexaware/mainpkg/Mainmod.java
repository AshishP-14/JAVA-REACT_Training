package com.hexaware.mainpkg;

import java.util.ArrayList;
import java.util.logging.Logger;

import com.hexaware.dao.ServiceProviderImpl;
import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.myexceptions.AccountNumberInvalidException;
import com.hexaware.myexceptions.InsufficientFundException;
import com.hexaware.myexceptions.NegativeAmountException;

public class Mainmod {
	
	private static final Logger LOGGER  = Logger.getLogger(Mainmod.class.getName());  
	
	public static void main(String[] args) {
		
		LOGGER.info("Starting Banking Application..");
		
		BankAccount obj1 = new BankAccount("Ashish","Current",1000.00);
		BankAccount obj2 = new BankAccount("Ayush","Savings",95000.50);
		BankAccount obj3 = new BankAccount("Akash","Current",30000.00);
	
		ArrayList<BankAccount> myList = new ArrayList<BankAccount>();
		myList.add(obj1);
		myList.add(obj2);
		myList.add(obj3);
		
		Bank myBank = new Bank("RBI",myList);
		System.out.println(myBank);
		//LOGGER.info(myBank.toString());
		
		ServiceProviderImpl  myServiceObj = new ServiceProviderImpl(myBank);

		try {
			LOGGER.info("Balance of acc 1111 : " );
			System.out.println(myServiceObj.checkbalance(1111));
			
		} catch (AccountNumberInvalidException e) {
			//System.out.println(e.getMessage());
			LOGGER.warning("AccountNumberInvalidException :" + e.getMessage());
		}
		
		try {
			LOGGER.info("Status of deposit : ");
			System.out.println(myServiceObj.deposit(1111, 5000));
		} catch (AccountNumberInvalidException e) {
			//System.out.println(e.getMessage());
			LOGGER.warning("AccountNumberInvalidException :" + e.getMessage());
		} catch (NegativeAmountException e) {
			//System.out.println(e.getMessage());
			LOGGER.warning("NegativeAmountException : " + e.getMessage());
		}
		
		try {
			LOGGER.info("Balance of account 1111 : ");
			System.out.println(myServiceObj.checkbalance(1111));
		} catch (AccountNumberInvalidException e) {
			//System.out.println(e.getMessage());
			LOGGER.warning("AccountNumberInvalidException : " + e.getMessage());
		}
	
		try {
			LOGGER.info("status of withdraw : ");
			System.out.println( myServiceObj.withdraw(1110, 2000));
		} catch (AccountNumberInvalidException e) {
			//System.out.println(e.getMessage());
			LOGGER.warning("AccountNumberInvalidException :" + e.getMessage());
		} catch (InsufficientFundException e) {
			//System.out.println(e.getMessage());
			LOGGER.warning("InsufficientFundException : " + e.getMessage());
		} catch (NegativeAmountException e) {
			//System.out.println(e.getMessage());
			LOGGER.warning("NegativeAmountException : " + e.getMessage());
		}
		
		try {
			LOGGER.info("Balance of account 1111 : ");
			System.out.println(myServiceObj.checkbalance(1111));
		} catch (AccountNumberInvalidException e) {
			//System.out.println(e.getMessage());
			LOGGER.warning("AccountNumberInvalidException : " + e.getMessage());
		}
		
		System.out.println("new account status : "+ myServiceObj.createAccount(new BankAccount("John","savings",5600.50)));
		System.out.println(myBank);
		
		try {
			LOGGER.info("status of remove account : ");
			System.out.println(myServiceObj.removeAccount(1110));
		} catch (AccountNumberInvalidException e) {
			//System.out.println(e.getMessage());
			LOGGER.warning("AccountNumberInvalidException : " + e.getMessage());
		}
		
		//System.out.println(myBank);
		LOGGER.info(myBank.toString());
		LOGGER.info("Exiting Banking Application...");
	}
	
}
